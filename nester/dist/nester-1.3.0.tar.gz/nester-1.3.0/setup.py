from distutils.core import setup

setup(
    name = 'nester',
    version = '1.3.0',
    py_modules = ['nester'],
    author = 'Kent',
    authour_email ='iklo120277@gmail.com',
    url = 'xxxx',
    description = 'a simple printer of nester lists',
    )
